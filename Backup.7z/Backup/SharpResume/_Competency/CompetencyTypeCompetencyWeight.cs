using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    [Serializable]
    [DebuggerStepThrough]
    [DesignerCategory( StringHelper.SharpResumeCorrectSpelling )]
    [XmlType( AnonymousType = true )]
    public class CompetencyTypeCompetencyWeight
    {
        [XmlElement( "NumericValue", typeof ( NumericValueType ) )] [XmlElement( "StringValue", typeof ( StringValue ) )] public object Item;

        [XmlElement( "SupportingInformation" )] public List< string > SupportingInformation;

        [XmlAttribute] public string type;
    }
}