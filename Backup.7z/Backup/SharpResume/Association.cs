using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    [Serializable]
    [DebuggerStepThrough]
    [DesignerCategory( StringHelper.SharpResumeCorrectSpelling )]
    [XmlType( AnonymousType = true )]
    [XmlRoot( Namespace = XmlNamespaces.HRXmlNamespace25, IsNullable = false )]
    public class Association : AssociationType
    {
        [XmlAttribute] public string type;
    }
}