using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    [DebuggerStepThrough]
    [DesignerCategory( StringHelper.SharpResumeCorrectSpelling )]
    [XmlType( Namespace = XmlNamespaces.HRXmlNamespace25 )]
    [XmlRoot( ElementName = "UserArea", Namespace = XmlNamespaces.HRXmlNamespace25, IsNullable = false )]
    public class UserAreaType
    {
        private List< XmlElement > _any;

        /// <summary>
        /// Gets or sets any.
        /// </summary>
        /// <value>Any.</value>
        [XmlAnyElement]
        public List< XmlElement > Any
        {
            get { return _any; }
            set { _any = value; }
        }
    }
}