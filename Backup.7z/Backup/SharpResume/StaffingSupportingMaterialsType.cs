using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    [Serializable]
    [DebuggerStepThrough]
    [DesignerCategory( StringHelper.SharpResumeCorrectSpelling )]
    [XmlType( Namespace = XmlNamespaces.HRXmlNamespace25 )]
    public class StaffingSupportingMaterialsType
    {
        public string Description;
        [XmlElement( "AttachmentReference", typeof ( StaffingSupportingMaterialsTypeAttachmentReference ) )] [XmlElement( "Link", typeof ( string ) )] public object Item;
    }
}