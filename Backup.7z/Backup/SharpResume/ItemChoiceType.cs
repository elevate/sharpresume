using System;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    [XmlType( Namespace =XmlNamespaces.HRXmlNamespace25, IncludeInSchema = false )]
    public enum ItemChoiceType
    {
        AnyDate,

        MonthDay,

        StringDate,

        Year,

        YearMonth
    }
}