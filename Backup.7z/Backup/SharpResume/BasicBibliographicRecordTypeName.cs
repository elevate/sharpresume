using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    [Serializable]
    [DebuggerStepThrough]
    [DesignerCategory( StringHelper.SharpResumeCorrectSpelling )]
    [XmlType( AnonymousType = true )]
    public class BasicBibliographicRecordTypeName : PersonNameType
    {
        [XmlAttribute] public string role;
    }
}