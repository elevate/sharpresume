using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    [DebuggerStepThrough]
    [DesignerCategory( StringHelper.SharpResumeCorrectSpelling )]
    [XmlType( Namespace = XmlNamespaces.HRXmlNamespace25 )]
    [XmlRoot( ElementName = "PersonName", Namespace = XmlNamespaces.HRXmlNamespace25, IsNullable = false )]
    public class PersonNameType
    {
        private List< PersonNameTypeAffix > _affix;

        private List< PersonNameTypeAlternateScript > _alternateScript;
        private List< PersonNameTypeFamilyName > _familyName;
        private string _formattedName;

        private List< string > _givenName;
        private string _legalName;

        private string _middleName;
        private string _preferredGivenName;

        [XmlAttribute] private string _script;

        [XmlElement( "AlternateScript" )]
        public List< PersonNameTypeAlternateScript > AlternateScript
        {
            get { return _alternateScript; }
            set { _alternateScript = value; }
        }

        [XmlElement( "Affix" )]
        public List< PersonNameTypeAffix > Affix
        {
            get { return _affix; }
            set { _affix = value; }
        }

        [XmlElement( "FamilyName" )]
        public List< PersonNameTypeFamilyName > FamilyName
        {
            get { return _familyName; }
            set { _familyName = value; }
        }

        public string MiddleName
        {
            get { return _middleName; }
            set { _middleName = value; }
        }

        public string Script
        {
            get { return _script; }
            set { _script = value; }
        }

        public string PreferredGivenName
        {
            get { return _preferredGivenName; }
            set { _preferredGivenName = value; }
        }

        [XmlElement( "GivenName" )]
        public List< string > GivenName
        {
            get { return _givenName; }
            set { _givenName = value; }
        }

        public string FormattedName
        {
            get { return _formattedName; }
            set { _formattedName = value; }
        }

        public string LegalName
        {
            get { return _legalName; }
            set { _legalName = value; }
        }
    }
}