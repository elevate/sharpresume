using System;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    [XmlType( AnonymousType = true )]
    public enum PersonNameTypeFamilyNamePrimary
    {
        @true,

        @false,

        undefined
    }
}