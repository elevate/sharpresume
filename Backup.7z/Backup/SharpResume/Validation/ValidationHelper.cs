//using System;

//namespace FrogsBrain.SharpResume.Validation
//{
//    /// <summary>
//    /// 
//    /// </summary>
//    public static class ValidationHelper
//    {
//        /// <summary>
//        /// Validates the email address.
//        /// </summary>
//        /// <param name="emailAddress">The email address.</param>
//        /// <returns></returns>
//        public static bool ValidateEmailAddress( string emailAddress )
//        {
//            throw new NotImplementedException();
//        }

//        /// <summary>
//        /// Validates the web address.
//        /// </summary>
//        /// <param name="webAddress">The web address.</param>
//        /// <returns></returns>
//        public static bool ValidateWebAddress( string webAddress )
//        {
//            throw new NotImplementedException();
//        }
//    }
//}
