//namespace FrogsBrain.SharpResume.Validation
//{
//    /// <summary>
//    /// 
//    /// </summary>
//    public static class PermissionsHelper
//    {
//        /// <summary>
//        /// Determines whether file i/o is permitted in the executing environment.
//        /// </summary>
//        /// <returns>
//        /// 	<c>true</c> if [is file IO permitted]; otherwise, <c>false</c>.
//        /// </returns>
//        public static bool IsFileIOPermitted()
//        {
//            return false;
//        }
//    }
//}
