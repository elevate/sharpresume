using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    [DebuggerStepThrough]
    [DesignerCategory( StringHelper.SharpResumeCorrectSpelling )]
    [XmlType( Namespace = XmlNamespaces.HRXmlNamespace25 )]
    [XmlRoot( "CompetencyId", Namespace = XmlNamespaces.HRXmlNamespace25, IsNullable = false )]
    public class EntityIdType : BaseSharpResumeObject< EntityIdType >
    {
        private string _idOwner;
        private List< EntityIdTypeIdValue > _idValue;

        private string _validFrom;

        private string _validTo;

        /// <summary>
        /// Initializes a new instance of the <see cref="EntityIdType"/> class.
        /// </summary>
        public EntityIdType()
        {
            _idValue = new List< EntityIdTypeIdValue >();
        }

        /// <summary>
        /// Gets or sets the id value.
        /// </summary>
        /// <value>The id value.</value>
        [XmlElement( ElementName="IdValue" )]
        public List< EntityIdTypeIdValue > IdValue
        {
            get { return _idValue; }
            set { _idValue = value; }
        }

        /// <summary>
        /// Gets or sets the valid from.
        /// </summary>
        /// <value>The valid from.</value>
        [XmlAttribute( AttributeName = "validFrom" )]
        public string ValidFrom
        {
            get { return _validFrom; }
            set { _validFrom = value; }
        }

        /// <summary>
        /// Gets or sets the valid to.
        /// </summary>
        /// <value>The valid to.</value>
        [XmlAttribute( AttributeName = "validTo" )]
        public string ValidTo
        {
            get { return _validTo; }
            set { _validTo = value; }
        }

        /// <summary>
        /// Gets or sets the id owner.
        /// </summary>
        /// <value>The id owner.</value>
        [XmlAttribute( AttributeName="idOwner" )]
        public string IdOwner
        {
            get { return _idOwner; }
            set { _idOwner = value; }
        }

        /// <summary>
        /// Indicates whether the current object is equal to another object of the same type.
        /// </summary>
        /// <param name="other">An object to compare with this object.</param>
        /// <returns>
        /// true if the current object is equal to the other parameter; otherwise, false.
        /// </returns>
        public override bool Equals( EntityIdType other )
        {
            //HACK: bad equality evaluation.
            //TODO: implement correct validation comparison
            if ( other == null )
            {
                return false;
            }
            return true;
        }
    }
}