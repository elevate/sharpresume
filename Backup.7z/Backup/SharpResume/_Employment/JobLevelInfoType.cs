using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    [Serializable]
    [DebuggerStepThrough]
    [DesignerCategory( StringHelper.SharpResumeCorrectSpelling )]
    [XmlType( Namespace = XmlNamespaces.HRXmlNamespace25 )]
    public class JobLevelInfoType
    {
        public string Comments;
        public string JobGrade;
        public string JobPlan;

        public string JobStep;
    }
}