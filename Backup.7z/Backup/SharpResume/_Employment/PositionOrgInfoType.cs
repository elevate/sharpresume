using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    [Serializable]
    [DebuggerStepThrough]
    [DesignerCategory( StringHelper.SharpResumeCorrectSpelling )]
    [XmlType( Namespace = XmlNamespaces.HRXmlNamespace25 )]
    public class PositionOrgInfoType
    {
        private EmploymentLocationSummaryType _locationSummary;
        private PostalAddressType _positionLocation;

        private string _website;

        /// <summary>
        /// Gets or sets the website.
        /// </summary>
        /// <value>The website.</value>
        [XmlElement( ElementName="WebSite" )]
        public string Website
        {
            get { return _website; }
            set { _website = value; }
        }

        /// <summary>
        /// Gets or sets the position location.
        /// </summary>
        /// <value>The position location.</value>
        public PostalAddressType PositionLocation
        {
            get { return _positionLocation; }
            set { _positionLocation = value; }
        }

        /// <summary>
        /// Gets or sets the location summary.
        /// </summary>
        /// <value>The location summary.</value>
        public EmploymentLocationSummaryType LocationSummary
        {
            get { return _locationSummary; }
            set { _locationSummary = value; }
        }
    }
}