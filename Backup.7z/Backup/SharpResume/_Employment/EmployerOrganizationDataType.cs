using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    [Serializable]
    [DebuggerStepThrough]
    [DesignerCategory( StringHelper.SharpResumeCorrectSpelling )]
    [XmlType( Namespace = XmlNamespaces.HRXmlNamespace25 )]
    public class EmployerOrganizationDataType
    {
        // [XmlRoot( ElementName = "EmployerOrgDataType" )]
        private EmpContactInfoType _employerContactInfo;
        private string _employerOrganizationName;
        private string _employerOrganizationType;
        private List< EmployerOrgDataTypePositionHistory > _positionHistory;
        private UserAreaType _userArea;

        /// <summary>
        /// Gets or sets the name of the employer organization.
        /// </summary>
        /// <value>The name of the employer organization.</value>
        [XmlElement( ElementName = "EmployerOrgName" )]
        public string EmployerOrganizationName
        {
            get { return _employerOrganizationName; }
            set { _employerOrganizationName = value; }
        }

        /// <summary>
        /// Gets or sets the employer contact info.
        /// </summary>
        /// <value>The employer contact info.</value>
        [XmlElement( ElementName = "EmployerContactInfo" )]
        public EmpContactInfoType EmployerContactInformation
        {
            get { return _employerContactInfo; }
            set { _employerContactInfo = value; }
        }

        /// <summary>
        /// Gets or sets the position history.
        /// </summary>
        /// <value>The position history.</value>
        [XmlElement( "PositionHistory" )]
        public List< EmployerOrgDataTypePositionHistory > PositionHistory
        {
            get { return _positionHistory; }
            set { _positionHistory = value; }
        }

        /// <summary>
        /// Gets or sets the user area.
        /// </summary>
        /// <value>The user area.</value>
        [XmlElement( ElementName = "UserArea" )]
        public UserAreaType UserArea
        {
            get { return _userArea; }
            set { _userArea = value; }
        }

        /// <summary>
        /// Gets or sets the type of the employer organization.
        /// </summary>
        /// <value>The type of the employer organization.</value>
        [XmlAttribute( AttributeName = "EmployerOrgType" )]
        public string EmployerOrganizationType
        {
            get { return _employerOrganizationType; }
            set { _employerOrganizationType = value; }
        }
    }
}