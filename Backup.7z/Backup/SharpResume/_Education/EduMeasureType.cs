using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    [DebuggerStepThrough]
    [DesignerCategory( StringHelper.SharpResumeCorrectSpelling )]
    [XmlType( Namespace = XmlNamespaces.HRXmlNamespace25 )]
    public class EduMeasureType
    {
        public string MeasureSystem;

        [XmlAttribute] public string measureType;
        public string MeasureValue;
    }
}