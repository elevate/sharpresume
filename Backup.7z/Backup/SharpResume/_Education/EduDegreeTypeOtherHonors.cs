using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    [DebuggerStepThrough]
    [DesignerCategory( StringHelper.SharpResumeCorrectSpelling )]
    [XmlType( AnonymousType = true )]
    public class EduDegreeTypeOtherHonors
    {
        [XmlAttribute] public string type;

        [XmlText] public string Value;
    }
}