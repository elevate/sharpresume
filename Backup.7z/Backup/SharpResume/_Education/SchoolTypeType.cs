using System;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    [XmlType( Namespace = XmlNamespaces.HRXmlNamespace25 )]
    public enum SchoolTypeType
    {
        current,

        prior,

        joint,

        degree
    }
}