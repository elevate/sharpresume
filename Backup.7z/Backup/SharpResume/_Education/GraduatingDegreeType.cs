using System;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    [XmlType( Namespace = XmlNamespaces.HRXmlNamespace25 )]
    public enum GraduatingDegreeType
    {
        graduating,

        qualifying
    }
}