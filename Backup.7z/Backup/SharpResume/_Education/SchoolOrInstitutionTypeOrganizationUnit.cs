using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    [DebuggerStepThrough]
    [DesignerCategory( StringHelper.SharpResumeCorrectSpelling )]
    [XmlType( AnonymousType = true )]
    public class SchoolOrInstitutionTypeOrganizationUnit
    {
        [XmlAttribute] public SchoolOrInstitutionTypeOrganizationUnitAttendanceStatus attendanceStatus;

        [XmlIgnore] public bool attendanceStatusSpecified;
        [XmlAttribute] public string organizationType;

        [XmlText] public string Value;
    }
}