using System;
using System.Xml.Serialization;

namespace FrogsBrain.SharpResume
{
    [Serializable]
    [XmlType( AnonymousType = true )]
    public enum SchoolOrInstitutionTypeOrganizationUnitAttendanceStatus
    {
        current,

        prior,

        unknown
    }
}